export const environment = {
  production: true,
  apiUrl: "http://3.13.184.88/fanzooma-backend-laravel-after-club/api",
  frontUrl: "http://3.13.184.88/after-club/fanzooma",
};
