export class DashboardShop {
  id: number;
  name: number;
  annual_goal_from: number;
  annual_goal_to: number;
  display_on_dashboard: string;
  type: string;
}