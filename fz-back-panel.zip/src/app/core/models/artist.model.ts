export class ArtistModel {
  _id: string;
  artist_id : string;
  status : number;
  name: string;
  description: string;
  facebookURL: string;
  webUrl : string;
}