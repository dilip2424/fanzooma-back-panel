export interface BaseModel {
    id: any;
  }
  