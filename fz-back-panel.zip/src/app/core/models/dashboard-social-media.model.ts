export class DashboardSocialMedia {
  id: number;
  name: number;
  fb_annual_goal_from: number;
  fb_annual_goal_to: number;
  tt_annual_goal_from: number;
  tt_annual_goal_to: number;
  insta_annual_goal_from: number;
  insta_annual_goal_to: number;
  display_on_dashboard: string;
  type: string;
}