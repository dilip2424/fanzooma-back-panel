import { PriceformatPipe } from './priceformat.pipe';

describe('PriceformatPipe', () => {
  it('create an instance', () => {
    const pipe = new PriceformatPipe();
    expect(pipe).toBeTruthy();
  });
});
