export const Roles = Object.freeze({
  ALLOW_ALL: 0,
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin',
});
